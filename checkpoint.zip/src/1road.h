#include "1mapelem.h"

class CRoad: public CMapElem
{
  public:
    CRoad() : CMapElem() {};
    print ();

  protected:

}