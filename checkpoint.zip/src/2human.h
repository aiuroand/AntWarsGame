#include "player.h"

class CHuman : public CPlayer
{
  public:
    CHuman () : CPlayer() {};
    MakeMove (){}; 
 
  private:

};