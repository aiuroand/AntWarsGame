#include "1mapelem.h"

class CAnt: public CMapElem
{
  public:
    CAnt() : CMapElem() {};
    print ();

  protected:

}