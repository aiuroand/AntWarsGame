#include < iostream >

int main ( void )
{

  return EXIT_SUCCESS;
}