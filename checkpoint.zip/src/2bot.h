#include "player.h"

class CBot : public CPlayer
{
  public:
    CBot () : CPlayer() {};
    MakeMove (){}; 
 
  private:

};