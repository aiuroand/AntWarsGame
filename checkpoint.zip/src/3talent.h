

class CTalent
{
  public:
    CTalent(){};
    useTalent() = 0;

  private:
    int m_Id;
    std::string m_Description;
}