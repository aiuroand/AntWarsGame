#include "1mapelem.h"

class CVoid : public CMapElem
{
  public:
    CVoid() : CMapElem() {};
    print ();

  protected:

}